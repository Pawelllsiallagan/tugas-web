Selamat Belajar Teman-Temen

User Interfacenya silahkan disesuaikan agar tidak terjadi kesamaan

Database silahkan di Import aja

Dan untuk Vhost silahkan di sesuaikan dengan tempat folder yang ada dengan menggunakan base url : http://poltek-kampar.com
